package com.oracle.shopping.service;

import java.util.Map;

import com.oracle.shopping.model.Item;

public interface ShoppingCartService {

	public void addItem(Item newItem, int quantity);
	public void updateItem(Item item, int quantity);
	public void removeItem(Item item);
	public int computePrice();
	public Map<Item, Integer> getShoppingCart();
}
