package jpa;

import jpa.entity.*;

import javax.persistence.*;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {
	private static final Logger LOGGER = Logger.getLogger("JPA");

	public static void main(String[] args) {
		Main main = new Main();
		main.run();
	}

	public void run() {
		EntityManagerFactory factory = null;
		EntityManager entityManager = null;
		try {
			factory = Persistence.createEntityManagerFactory("PersistenceUnit");
			entityManager = factory.createEntityManager();
			// TODO: uncomment these calls after each task is done
			
//			persistPerson(entityManager);
//			persistGeek(entityManager);
//			loadPersons(entityManager);
//			addPhones(entityManager);
			createProject(entityManager);
			queryProject(entityManager);
		} catch (Exception e) {
			LOGGER.log(Level.SEVERE, e.getMessage(), e);
			e.printStackTrace();
		} finally {
			if (entityManager != null) {
				entityManager.close();
			}
			if (factory != null) {
				factory.close();
			}
		}
	}

	private void queryProject(EntityManager entityManager) {
		TypedQuery<Project> query = entityManager.createQuery("from Project p where p.projectPeriod.startDate = :startDate", Project.class).setParameter("startDate", createDate(1, 1, 2015));
		List<Project> resultList = query.getResultList();
		for (Project project : resultList) {
			LOGGER.info(project.getProjectPeriod().getStartDate().toString());
		}
	}

	private void createProject(EntityManager entityManager) {
		List<Geek> resultList = entityManager.createQuery("from Geek where favouriteProgrammingLanguage = :fpl", Geek.class).setParameter("fpl", "Java").getResultList();
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
		Project project = new Project();
		project.setTitle("Java Project");
		project.setProjectType(Project.ProjectType.TIME_AND_MATERIAL);
		Period period = new Period();
		period.setStartDate(createDate(1, 1, 2015));
		period.setEndDate(createDate(31, 12, 2015));
		project.setProjectPeriod(period);
		for (Geek geek : resultList) {
			project.getGeeks().add(geek);
			geek.getProjects().add(project);
		}
		entityManager.persist(project);
		transaction.commit();
	}

	private Date createDate(int day, int month, int year) {
		GregorianCalendar gc = new GregorianCalendar();
		gc.set(Calendar.DAY_OF_MONTH, day);
		gc.set(Calendar.MONTH, month - 1);
		gc.set(Calendar.YEAR, year);
		gc.set(Calendar.HOUR_OF_DAY, 0);
		gc.set(Calendar.MINUTE, 0);
		gc.set(Calendar.SECOND, 0);
		gc.set(Calendar.MILLISECOND, 0);
		return new Date(gc.getTimeInMillis());
	}

	private void addPhones(EntityManager entityManager) {
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Person> query = builder.createQuery(Person.class);
		Root<Person> personRoot = query.from(Person.class);
		query.where(builder.and(
				builder.equal(personRoot.get("firstName"), "Homer"),
				builder.equal(personRoot.get("lastName"), "Simpson")));
		List<Person> resultList = entityManager.createQuery(query).getResultList();
		for (Person person : resultList) {
			Phone phone = new Phone();
			phone.setNumber("+49 1234 456789");
			entityManager.persist(phone);
			person.getPhones().add(phone);
			phone.setPerson(person);
		}
		transaction.commit();
	}

	private void persistPerson(EntityManager entityManager) {
		/* TODO insert some persons in the database
		 * 
		 * Get a transaction.
		 * Create some persons and persist them.
		 * Commit the transaction.
		 * 
		 * TODO later: create an IdCard and for each of the persons you add and persist them all.
		 */
	}

	private void persistGeek(EntityManager entityManager) {
		/*
		 * TODO insert some Geeks in the same way you insert Persons.
		 * Populate a few instances with some proper data.
		 * Fill their Geek attributes as well as their Person attributes.
		 */
	}

	private void loadPersons(EntityManager entityManager) {
		/*
		 * TODO fetch all the Persons from the table.
		 * 
		 * Use a TypedQuery. Get its result list and then iterate on it.
		 * Build a String  out of the entire result and print it to stdout.
		 * 
		 * TODO later: join with the phones table. Adjust the result String appropriately.
		 */
		entityManager.clear();
		List<Person> resultList = null;
			
		for (Person person : resultList) {
			StringBuilder sb = new StringBuilder();
			sb.append(person.getFirstName()).append(" ").append(person.getLastName());
			
			// TODO if this person is in fact a Geek, append its Geek info
			
			// TODO when fetching IdCards and Phones be sure to append the relevant info to the string builder
			sb.append(System.lineSeparator());
			LOGGER.info(sb.toString());
		}
	}
}
