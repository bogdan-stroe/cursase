package jpa.entity;

import javax.persistence.*;

/*
 * TODO 
 * 
 * Make this an entity.
 * Map it to the T_PHONE table.
 * 
 * Annotate the properties.
 */
public class Phone {
	private Long id;
	private String number;
	private Person person;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}
}
