package jpa.entity;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/*
 * TODO
 * 
 * Make this class an entity.
 * Annotate its own properties first.
 * 
 * Later, annotate the join properties with the correct annotations.
 */
public class Project {
	private Long id;
	private String title;
	private List<Geek> geeks = new ArrayList<Geek>();
	private ProjectType projectType;
	private Period projectPeriod;
	private List<Period> billingPeriods = new ArrayList<Period>();

	public enum ProjectType {
		FIXED, TIME_AND_MATERIAL
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	/*
	 * TODO what type of relationship is Project - Geek?
	 * 
	 * Place the correct annotation(s) here.
	 * What are the join/inverse join columns here?
	 */
	public List<Geek> getGeeks() {
		return geeks;
	}

	public void setGeeks(List<Geek> geeks) {
		this.geeks = geeks;
	}

	@Enumerated(EnumType.STRING)
	public ProjectType getProjectType() {
		return projectType;
	}

	public void setProjectType(ProjectType projectType) {
		this.projectType = projectType;
	}

	@Embedded
	public Period getProjectPeriod() {
		return projectPeriod;
	}

	public void setProjectPeriod(Period projectPeriod) {
		this.projectPeriod = projectPeriod;
	}

	@ElementCollection
	@CollectionTable(
			name="T_BILLING_PERIOD",
			joinColumns=@JoinColumn(name="PROJECT_ID")
	)
	public List<Period> getBillingPeriods() {
		return billingPeriods;
	}

	public void setBillingPeriods(List<Period> billingPeriods) {
		this.billingPeriods = billingPeriods;
	}
}
