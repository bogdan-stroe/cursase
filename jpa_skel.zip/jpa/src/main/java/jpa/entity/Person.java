package jpa.entity;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

/*
 * TODO 
 * Give the correct annotations for this class and make it an entity.
 * Map this entity on the table T_PERSON.
 * 
 * Annotate the properties appropriately.
 * 
 */
public class Person {
	private Long id;
	private String firstName;
	private String lastName;
	private IdCard idCard;
	private List<Phone> phones = new ArrayList<Phone>();

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}


	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public IdCard getIdCard() {
		return idCard;
	}

	public void setIdCard(IdCard idCard) {
		this.idCard = idCard;
	}

	public List<Phone> getPhones() {
		return phones;
	}

	public void setPhones(List<Phone> phones) {
		this.phones = phones;
	}
}
